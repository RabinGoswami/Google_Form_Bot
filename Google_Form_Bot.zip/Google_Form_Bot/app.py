from flask import Flask, render_template, request, redirect, url_for, session, flash
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import ElementClickInterceptedException
import random
import time
import sqlite3
import hashlib
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = "cyberpunk-form-bot-secret-key-2024"

# Database setup
DATABASE = 'formbot.db'

def get_db():
    """Create database connection"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def check_column_exists(conn, table_name, column_name):
    """Check if a column exists in a table"""
    cursor = conn.cursor()
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [column[1] for column in cursor.fetchall()]
    return column_name in columns

def init_db():
    """Initialize database with users table"""
    conn = get_db()
    
    # Create users table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create execution_history table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS execution_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            responses_count INTEGER NOT NULL,
            status TEXT NOT NULL,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Add form_url column if it doesn't exist
    if not check_column_exists(conn, 'execution_history', 'form_url'):
        try:
            conn.execute('ALTER TABLE execution_history ADD COLUMN form_url TEXT DEFAULT ""')
            print("✅ Added 'form_url' column to execution_history table")
        except Exception as e:
            print(f"⚠️ Could not add form_url column: {e}")
    
    conn.commit()
    conn.close()

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def login_required(f):
    """Decorator to require login for routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Initialize database on startup
with app.app_context():
    init_db()

# ==================== AUTHENTICATION ROUTES ====================

@app.route('/')
def index():
    """Redirect to register if not logged in, otherwise dashboard"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('register'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Validation
        if not username or not email or not password:
            flash('All fields are required!', 'error')
            return render_template('register.html')
        
        if len(password) < 8:
            flash('Password must be at least 8 characters long!', 'error')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('register.html')
        
        # Check if user exists
        conn = get_db()
        existing_user = conn.execute(
            'SELECT * FROM users WHERE username = ? OR email = ?',
            (username, email)
        ).fetchone()
        
        if existing_user:
            flash('Username or email already exists!', 'error')
            conn.close()
            return render_template('register.html')
        
        # Create new user
        hashed_pw = hash_password(password)
        try:
            conn.execute(
                'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                (username, email, hashed_pw)
            )
            conn.commit()
            flash(f'Account created successfully! Welcome {username}!', 'success')
            conn.close()
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'Error creating account: {str(e)}', 'error')
            conn.close()
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        if not username or not password:
            flash('Username and password are required!', 'error')
            return render_template('login.html')
        
        conn = get_db()
        user = conn.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, hash_password(password))
        ).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash(f'Welcome back, {user["username"]}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password!', 'error')
            return render_template('login.html')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Logout user"""
    username = session.get('username', 'User')
    session.clear()
    flash(f'Goodbye {username}! You have been logged out.', 'success')
    return redirect(url_for('login'))

# ==================== DASHBOARD & MAIN FUNCTIONALITY ====================

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard with statistics"""
    conn = get_db()
    
    # Check if form_url column exists
    has_form_url = check_column_exists(conn, 'execution_history', 'form_url')
    
    # Get user statistics
    stats = conn.execute('''
        SELECT 
            COUNT(*) as total_runs,
            SUM(responses_count) as total_responses,
            AVG(CASE WHEN status = 'success' THEN 1.0 ELSE 0.0 END) * 100 as success_rate
        FROM execution_history
        WHERE user_id = ?
    ''', (session['user_id'],)).fetchone()
    
    # Get recent activity with conditional form_url
    if has_form_url:
        recent_activity = conn.execute('''
            SELECT responses_count, status, executed_at, form_url
            FROM execution_history
            WHERE user_id = ?
            ORDER BY executed_at DESC
            LIMIT 5
        ''', (session['user_id'],)).fetchall()
    else:
        recent_activity = conn.execute('''
            SELECT responses_count, status, executed_at
            FROM execution_history
            WHERE user_id = ?
            ORDER BY executed_at DESC
            LIMIT 5
        ''', (session['user_id'],)).fetchall()
    
    conn.close()
    
    return render_template('dashboard.html', 
                         stats=stats, 
                         recent_activity=recent_activity,
                         username=session.get('username'))

@app.route('/generate', methods=['GET', 'POST'])
@login_required
def generate():
    """Response generation page"""
    if request.method == 'POST':
        try:
            # Get form URL from user input
            form_url = request.form.get("form_url", "").strip()
            total = int(request.form["responses"])
            
            # Validate form URL
            if not form_url:
                flash('Please provide a Google Form URL!', 'error')
                return render_template('index.html', username=session.get('username'))
            
            if "docs.google.com/forms" not in form_url:
                flash('Please provide a valid Google Forms URL!', 'error')
                return render_template('index.html', username=session.get('username'))
            
            if total < 1 or total > 200:
                flash('Please enter a number between 1 and 200!', 'error')
                return render_template('index.html', username=session.get('username'))

            # Chrome options with better Windows compatibility
            chrome_options = webdriver.ChromeOptions()
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            
            # Try to create driver - this will now give better error messages
            try:
                # Method 1: Try using Chrome directly (most reliable on Windows)
                driver = webdriver.Chrome(options=chrome_options)
            except Exception as e:
                flash(f'❌ ChromeDriver Error: Please install Chrome and make sure ChromeDriver is compatible with your Chrome version. Error: {str(e)}', 'error')
                return render_template('index.html', username=session.get('username'))

            wait = WebDriverWait(driver, 15)
            success_count = 0

            for i in range(total):
                try:
                    driver.get(form_url)
                    time.sleep(3)

                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(2)

                    # TEXT INPUTS
                    for text in driver.find_elements(By.XPATH, '//input[@type="text"]'):
                        text.send_keys(f"Test Response {random.randint(1, 1000)}")

                    # PARAGRAPH INPUTS
                    for area in driver.find_elements(By.XPATH, '//textarea'):
                        area.send_keys("This is an automatically generated response for testing purposes.")

                    # RADIO QUESTIONS
                    radio_groups = driver.find_elements(By.XPATH, '//div[@role="radiogroup"]')
                    for group in radio_groups:
                        radios = group.find_elements(By.XPATH, './/div[@role="radio"]')
                        if radios:
                            choice = random.choice(radios)
                            driver.execute_script(
                                "arguments[0].scrollIntoView({block: 'center'});", choice
                            )
                            try:
                                wait.until(EC.element_to_be_clickable(choice))
                                choice.click()
                            except ElementClickInterceptedException:
                                driver.execute_script("arguments[0].click();", choice)
                            time.sleep(0.5)

                    # CHECKBOX QUESTIONS
                    checkbox_groups = driver.find_elements(By.XPATH, '//div[@role="list"]')
                    for group in checkbox_groups:
                        boxes = group.find_elements(By.XPATH, './/div[@role="checkbox"]')
                        if boxes:
                            box = random.choice(boxes)
                            driver.execute_script(
                                "arguments[0].scrollIntoView({block: 'center'});", box
                            )
                            try:
                                wait.until(EC.element_to_be_clickable(box))
                                box.click()
                            except ElementClickInterceptedException:
                                driver.execute_script("arguments[0].click();", box)
                            time.sleep(0.5)

                    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                    time.sleep(2)

                    submit = wait.until(
                        EC.element_to_be_clickable((By.XPATH, '//span[text()="Submit"]'))
                    )
                    submit.click()
                    success_count += 1

                    time.sleep(random.randint(4, 6))
                    
                except Exception as e:
                    print(f"Error on response {i+1}: {str(e)}")
                    continue

            driver.quit()
            
            # Save to database with conditional form_url
            conn = get_db()
            if check_column_exists(conn, 'execution_history', 'form_url'):
                conn.execute(
                    'INSERT INTO execution_history (user_id, form_url, responses_count, status) VALUES (?, ?, ?, ?)',
                    (session['user_id'], form_url, success_count, 'success')
                )
            else:
                conn.execute(
                    'INSERT INTO execution_history (user_id, responses_count, status) VALUES (?, ?, ?)',
                    (session['user_id'], success_count, 'success')
                )
            conn.commit()
            conn.close()
            
            flash(f'✅ {success_count} out of {total} responses successfully submitted!', 'success')
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            flash(f'❌ Error: {str(e)}', 'error')
            return render_template('index.html', username=session.get('username'))

    return render_template('index.html', username=session.get('username'))

# ==================== OTHER PAGES ====================

@app.route('/history')
@login_required
def history():
    """Execution history page"""
    conn = get_db()
    
    # Check if form_url column exists
    has_form_url = check_column_exists(conn, 'execution_history', 'form_url')
    
    # Get execution history with conditional form_url
    if has_form_url:
        executions = conn.execute('''
            SELECT id, form_url, responses_count, status, executed_at
            FROM execution_history
            WHERE user_id = ?
            ORDER BY executed_at DESC
            LIMIT 20
        ''', (session['user_id'],)).fetchall()
    else:
        executions = conn.execute('''
            SELECT id, responses_count, status, executed_at
            FROM execution_history
            WHERE user_id = ?
            ORDER BY executed_at DESC
            LIMIT 20
        ''', (session['user_id'],)).fetchall()
    
    # Get summary stats
    stats = conn.execute('''
        SELECT 
            COUNT(*) as total_executions,
            SUM(responses_count) as total_responses,
            AVG(CASE WHEN status = 'success' THEN 1.0 ELSE 0.0 END) * 100 as success_rate
        FROM execution_history
        WHERE user_id = ?
    ''', (session['user_id'],)).fetchone()
    
    conn.close()
    
    return render_template('history.html', 
                         executions=executions, 
                         stats=stats,
                         username=session.get('username'))

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    """Settings page"""
    if request.method == 'POST':
        flash('Settings saved successfully!', 'success')
        return redirect(url_for('settings'))
    
    return render_template('settings.html', username=session.get('username'))

@app.route('/about')
@login_required
def about():
    """About page"""
    return render_template('about.html', username=session.get('username'))


if __name__ == "__main__":
    print("=" * 60)
    print("🤖 FORM BOT - Cyberpunk Edition")
    print("=" * 60)
    print("✨ Server starting...")
    print("📍 URL: http://127.0.0.1:8000")
    print("🔐 Flow: Register → Login → Dashboard")
    print("=" * 60)
    app.run(host="127.0.0.1", port=8000, debug=True)