"""
Database Migration Script
Adds form_url column to execution_history table
"""

import sqlite3
import os

DATABASE = 'formbot.db'

def migrate_database():
    """Add form_url column to execution_history table"""
    
    if not os.path.exists(DATABASE):
        print(f"❌ Database file '{DATABASE}' not found!")
        return False
    
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(execution_history)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'form_url' in columns:
            print("✅ Column 'form_url' already exists. No migration needed.")
            conn.close()
            return True
        
        # Add the column
        print("🔄 Adding 'form_url' column to execution_history table...")
        cursor.execute('''
            ALTER TABLE execution_history 
            ADD COLUMN form_url TEXT DEFAULT ''
        ''')
        
        conn.commit()
        print("✅ Migration completed successfully!")
        print("📊 Column 'form_url' has been added to execution_history table.")
        
        # Verify the change
        cursor.execute("PRAGMA table_info(execution_history)")
        columns = [column[1] for column in cursor.fetchall()]
        print(f"📋 Current columns: {', '.join(columns)}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Migration failed: {str(e)}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("🔧 DATABASE MIGRATION TOOL")
    print("=" * 60)
    migrate_database()
    print("=" * 60)
